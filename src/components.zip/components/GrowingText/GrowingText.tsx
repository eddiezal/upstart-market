import React, { useState, useEffect, useRef } from "react";
import styled, { keyframes } from "styled-components";

const GrowingText: React.FC = () => {
  const [visibleIndex, setVisibleIndex] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Observer to trigger animations when in viewport
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let index = 0;
          const interval = setInterval(() => {
            index++;
            setVisibleIndex(index);
            if (index === 3) clearInterval(interval);
          }, 600); // **Each word appears every 600ms**
        }
      },
      { threshold: 0.5 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <MessageContainer ref={sectionRef}>
      <TextRow>
        <Word visible={visibleIndex >= 1} delay={0}>
          Together
        </Word>
        <Word visible={visibleIndex >= 2} delay={1}>
          We Grow
        </Word>
      </TextRow>
      <StrongWord visible={visibleIndex >= 3} delay={2}>
        Stronger
      </StrongWord>
      <Underline />
    </MessageContainer>
  );
};

export default GrowingText;
